<?php

$sql = array();
$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'intolerance_allergy`';
$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'product_intolerance_allergy`';
